cd "\Table1\"
import delimited "statafile.csv", clear

* Generate variables
replace true_contribution = true_worst if true_worst < 0
replace false_contribution = false_worst if false_worst < 0
//replace true_worst = 0 if true_worst < 0
//replace false_worst = 0 if false_worst < 0

g hdlowerworst = true_worst < false_worst
tabstat  hdlowerworst, by(year) stat(mean N)
bysort id: g sampleyear = _N
sort id year
bysort id: g yrinpanel = _n
bysort id: egen startyear = min(year)
g yrsince1st = year - startyear 
g true_prm = true_prmmspty * 12
g false_prm = false_prmmspty * 12
g diffprm = (- false_prmmspty + true_prmmspty) * 12
g diffmoop = true_moop - false_moop
g diffnetprm = true_netprm - false_netprm
g diffworst = true_worst - false_worst
g diffwrk = (true_wkrspty - false_wkrspty) * 12
bysort id: egen endyear = max(year)
g length = endyear - startyear + 1
// identify firms with HSA only
g diffcont = true_contribution - false_contribution
g hsa = true_hra == 0 
replace true_hsa = . if hsa == 0
replace true_hra = . if hsa == 1
bysort id: egen hsasd = sd(hsa)

bysort id: egen hdddctsd = sd(true_ddct)
bysort id: egen ldddctsd = sd(false_ddct)
bysort id: egen maxpanel = max(panel2)
g allpanel = maxpanel == 1

g subsam = 1
replace subsam = 0 if sampleyear == 1
replace subsam = 0 if sampleyear != length
replace subsam = 0 if allpanel == 0
g subsam2 = subsam
replace subsam2 = 0 if hsa == 0
replace subsam2 = 0 if hsasd > 0 & hsasd !=.

g hrahsa = true_hsa if hsa == 1
replace hrahsa = true_hra if hsa == 0

* Table 1:
tabstat diffddct diffmoop diffprm diffwrk hrahsa diffworst hdlowerworst, ///
	by(year) stat(mean sd n)