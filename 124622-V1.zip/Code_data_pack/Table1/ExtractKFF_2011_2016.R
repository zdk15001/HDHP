
library(tidyverse)
library(lfe)
rm(list=ls())

getrat2 <- function(yr) {
  
  # read in dataset
  ehb2011 <- read_csv(paste("health_benefits_",as.character(yr),".csv", sep=""),
                      guess_max = 5700)
  if (yr>2011) { ehb2011 <- select(ehb2011, -hmo2, -ppo2, -pos2)}
  
  
  # edit column names
  modifyname <- function(key1, key2, sk, numb,dtfrm) {
    names2hmo1 <- dtfrm %>%
      select(id, matches(key1)) %>%
      colnames() %>%
      str_replace(sk,"pty") 
    names2hmo2 <- dtfrm %>%
      select(id, matches(key2)) %>%
      colnames() %>%
      str_replace(key2, "pty")
    names2hmo <- c(names2hmo1, names2hmo2[-1])
    subhmo <- ehb2011 %>%
      select(id,matches(key1), matches(key2)) %>%
      setNames(names2hmo) %>%
      filter(!is.na(prmmspty)) %>%
      filter(!is.na(pty6)) %>%
      mutate(plantype = numb) 
      #select(id, prmmspty, wkrspty, pty9bx, plantype, )
    return(subhmo)
  }
  
  # reshape dataset to plan level
  subhmo <- modifyname("^d\\d+", "hmo", "^d", 1,ehb2011)
  subppo <- modifyname("^e\\d+", "ppo", "^e", 2,ehb2011)
  subpos <- modifyname("^f\\d+", "pos", "^f", 3,ehb2011)
  subhdp <- modifyname("^g\\d+", "hdp", "^g", 4,ehb2011)
  
  a <- Reduce(intersect, list(colnames(subhmo), colnames(subpos), 
                              colnames(subppo), colnames(subhdp)))
  subhmo <- subhmo %>%
    select(a)
  subpos <- subpos %>%
    select(a) 
  subppo <- subppo %>%
    select(a) 
  subhdp <- subhdp %>%
    select(a)
  suball <- rbind(subhmo, subppo, subpos, subhdp)
  
  ehb2011N <- ehb2011 %>%
    left_join(suball, by = "id") %>%
    filter(!is.na(prmmspty)) %>%
    #filter(!is.na(pty6)) %>%
    #filter(!is.na(pty29)) %>%
    #filter(!is.na(pty18)) %>%
    mutate(hsa = (plantype == 4) * replace_na(g43ann,0)) %>%
    mutate(netprm = wkrspty * 12 - hsa) %>%
    mutate(hra = (plantype == 4) * replace_na(g41, 0)) 
    
  {ifelse((yr == 2012 || yr == 2015), ehb2011N <- mutate(ehb2011N, drugddct  = replace_na(ehb2011N$pty27a, 0)), 
            ehb2011N <- mutate(ehb2011N, drugddct = 0))} 

  ehb2011N <- ehb2011N %>%
    filter(!is.na(pty9bx)) %>%
    mutate(moop = pty9bx) %>%
    mutate(ddct = replace_na(ddctspty, 0) + replace_na(drugddct, 0)) %>%
    #filter(moop <= 6850) %>%
    filter(ddctspty + drugddct <= pty9bx) %>%
    #filter(moop %% 5 ==0) %>%
    #filter(ddctspty %%5 ==0) %>%
    mutate(worst = netprm - hra + moop ) %>%
    filter(!is.na(g43ann) | !is.na(g41)) 
  temp <- ehb2011N %>%
    count(id) %>%
    filter(n==2)
  a <- ehb2011N %>%
    group_by(id) %>%
    summarise(tt = sum(plantype==4)) %>%
    filter(tt == 1)
  ehb2011N <- ehb2011N %>%
    semi_join(temp, by = "id") %>%
    semi_join(a, by = "id") %>%
    filter(!is.na(prmmshdp)) 
  
  
  # reshape dataset so that each obs is a firm
  res2011 <- ehb2011N %>%
    select(id, worst, plantype, netprm, hra, hsa, moop, ddct, prmmspty, 
           wkrspty, panel2) %>%
    mutate(pty = plantype==4) %>%
    mutate(contribution = hra + hsa + (prmmspty*12 - wkrspty*12)) %>%
    select(id, panel2, pty, netprm, 
           hra, hsa, moop, ddct, prmmspty, 
           wkrspty,  contribution, worst) %>%
    gather(variable, value, -(id:pty)) %>%
    unite(temp, pty, variable) %>%
    spread(temp, value) %>%
    #mutate(diffwst_flag = (TRUE_worst - FALSE_worst)>0) %>%
    mutate(diffddct = (TRUE_ddct - FALSE_ddct)) %>%
    mutate(year = yr) 
  return(res2011)
}

res2011 <- getrat2(2011) 
res2012 <- getrat2(2012) 
res2013 <- getrat2(2013) 
res2014 <- getrat2(2014)
res2015 <- getrat2(2015) 
res2016 <- getrat2(2016) 

res2014 <- res2014 %>%
  rename(pp = "panel2") %>%
  mutate(panel2 = (pp == "Non-Panel") + 1) 
resall <- bind_rows(res2011, res2012, res2013, res2014, res2015, res2016)
write_csv(resall, "statafile.csv")

