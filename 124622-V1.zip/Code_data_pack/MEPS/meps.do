**************************************************************************
*Create MEPS spending groups*
*Chenyuan Liu (cliu439@wisc.edu)
*Created on 11 Feb 2017
*Last modified on 27 Feb 2020
clear
set matsize 1000
set more off
cd "\MEPS\"
use H171.dta

*Create sample as individuals who are covered by employer/union insurance throughout 2014
g peg14=PEGAP14==1 & PEGAU14==1 & PEGDE14==1 & PEGFE14==1 & PEGJA14==1 & PEGJL14==1 & PEGJU14==1 & PEGMA14==1 & PEGMY14==1 & PEGNO14==1 & PEGOC14==1 & PEGSE14==1 
g sample=peg14==1

*Define survey dataset and attach weights
svyset [pweight = PERWT14F], strata(VARSTR) psu(VARPSU)

*Recode some variables
g female=SEX-1
g age=AGE14X
g age2=age^2
g age3=age^3
g healthy=5-RTHLTH31
replace sample=0 if healthy>5
g spending=TOTEXP14
svy,subpop(sample): reg spending female age age2 age3 i.healthy female#i.healthy female#i.healthy#c.age female#c.age female#c.age2 female#c.age3 c.age#i.healthy c.age2#i.healthy c.age3#i.healthy
predict ybar


*Separate data into 2 groups based on predicted value
//ssc install egenmore
xtile ybarr=ybar if sample==1, nq(2)


*Calculate spending distribution for each group
g cat=.
replace cat=0 if spending==0
foreach y in spending {
	foreach i in 100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000 2100 2200 2300 2400 2500 2600 2700 2800 2900 3000 3100 3200 3300 3400 3500 3600 3700 3800 3900 4000 4100 4200 4300 4400 4500 4600 4700 4800 4900 5000 5100 5200 5300 5400 5500 5600 5700 5800 5900 6000 6100 6200 6300 6400 6500 7500 10000 15000 20000 25000 30000 35000 40000 45000 50000 100000 200000 300000 400000{
	replace cat=`i' if `y'<=`i' & cat==.
	}
}

log using "MEPSdist_2", replace
svy,subpop(sample): mean spending, over (ybarr cat)
svy,subpop(sample): proportion cat, over (ybarr)
svy,subpop(sample): mean spending, over (cat)
svy,subpop(sample): proportion cat
log close
